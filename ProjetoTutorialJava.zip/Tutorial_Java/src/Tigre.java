
public class Tigre extends Felino {
	
	public void emitirSom() {   // SOBRECARGA DA FUNCAO
		System.out.println("o tigre rugiu");
	}

}
